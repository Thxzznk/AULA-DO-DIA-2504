/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.pkg2.pkgdo.dia.pkg25042025;

import javax.swing.JOptionPane;

/**
 *
 * @author thierry.smsantos
 */
public class Aula2DoDia25042025 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //for (int i = 1; i < 8; i++) {
       //for (int i = 1; i <= 8; i++) {
            //JOptionPane.showMessageDialog(null, "repita");
           int opcao = JOptionPane.showConfirmDialog(null, "Voce joga algum jogo?");
           if (opcao ==0) {
            JOptionPane.showMessageDialog(null, "legal, continue jogando");
        }
           else if (opcao== 1) {
            JOptionPane.showMessageDialog(null, "que pena, deveria começar");
        }
           else if (opcao== 2) {
    JOptionPane.showMessageDialog(null, "porque isso cara???");
        }
           else if (opcao== -1){
    JOptionPane.showConfirmDialog(null, "tem certeza?");
    JOptionPane.showMessageDialog(null, "ok entao");
        }
           else {
               
           }
    }
}    
    

