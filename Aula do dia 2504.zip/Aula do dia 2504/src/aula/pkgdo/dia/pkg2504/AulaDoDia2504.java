/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.pkgdo.dia.pkg2504;

import javax.swing.JOptionPane;

/**
 *
 * @author thierry.smsantos
 */
public class AulaDoDia2504 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //String cpf= JOptionPane.showInputDialog(null,"digite seu cpf");
        //String nome= JOptionPane.showInputDialog(null,"digite seu nome");
        //JOptionPane.showMessageDialog(null, " Seu cpf: "+ cpf + " Seu nome: " + nome);
        
       
    }
    
}
